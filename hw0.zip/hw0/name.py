print('Jason')
print('Jay-sun')
print("""
I understand that copying code from another student, or any source other than the instructors, is considered cheating
in Chem 121.  Submitted assignments that contain inappropriately shared code will receive a score of zero and may be 
grounds for failing the course.
""")
